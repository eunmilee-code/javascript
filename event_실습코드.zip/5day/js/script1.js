const button = document.getElementById('clickButton');
const result = document.getElementById('result');

let clickCount = 0;

function handleButtonClick() {
    clickCount++;
    result.textContent = "호출횟수 : " + clickCount;

    if (clickCount === 10) {
        result.textContent = "성공!";
       // button.removeEventListener('click', handleButtonClick); // 10번 클릭 후 이벤트 리스너 제거
    }
}

button.addEventListener('click', handleButtonClick);