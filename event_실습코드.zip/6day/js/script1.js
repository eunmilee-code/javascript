let box = document.getElementById("box"); 
let x = 50; 
let y = 50; 

// function showPoint(event) {
//     console.log("event.clientX : "+ event.clientX);  
//     console.log("event.clientY : "+ event.clientY);  
// }

function position(event) {   //event 객체. 이벤트들에 대한 정보 가지고 있음. 브자우저에서 자동으로 제공됨 별도 정의 필요없음.
    console.log("event.code : "+ event.code);  

// 화면 넘어가지 않도록 코딩
    // let maxX = window.innerWidth - box.offsetWidth;  // 화면의 너비에서 박스의 너비를 뺀 값
    // let maxY = window.innerHeight - box.offsetHeight;  // 화면의 높이에서 박스의 높이를 뺀 값

    // if (event.code == "ArrowUp") {
    //     y = Math.max(y - 10, 0);  // y값이 0보다 작아지지 않도록 함
    // } else if (event.code == "ArrowDown") {
    //     y = Math.min(y + 10, maxY);  // y값이 maxY보다 커지지 않도록 함
    // } else if (event.code == "ArrowLeft") {
    //     x = Math.max(x - 10, 0);  // x값이 0보다 작아지지 않도록 함
    // } else if (event.code == "ArrowRight") {
    //     x = Math.min(x + 10, maxX);  // x값이 maxX보다 커지지 않도록 함
    // }

    // box.style.top = y + "px";
    // box.style.left = x + "px";


    if (event.code == "ArrowUp") {    // event.code 눌러진 키 를 문자열값으로 가지고 있다.  
        y -= 10;   
        box.style.top = y + "px";   
    } else if (event.code == "ArrowDown") {   
        y += 10;   
        box.style.top = y + "px";   
    } else if (event.code == "ArrowLeft") {   
        x -= 10;   
        box.style.left = x + "px"; 
    } else if (event.code == "ArrowRight") { 
        x += 10;   
        box.style.left = x + "px";   
    } 
}

document.addEventListener("keydown", position);
// box.addEventListener('mousemove', showPoint);
