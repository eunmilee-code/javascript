/* login.js */
const form = document.querySelector('form');
const usernameInput = document.getElementById('username');
const passwordInput = document.getElementById('password');
const loginButton = document.getElementById('login-btn');

form.addEventListener('submit', function(event) {
    event.preventDefault(); // 기본 동작을 막음

    // 입력된 값 가져오기
    const username = usernameInput.value;
    const password = passwordInput.value;
console.log (username);
console.log (password);
    // 로그인 처리
    if (username === 'admin' && password === '1234') {
    alert('로그인 성공!');
    // 여기에 로그인 성공 후 처리할 코드 작성
    } else {
    alert('로그인 실패! 다시 시도해주세요.');
    // 여기에 로그인 실패 후 처리할 코드 작성
    }
});
