const inputField = document.getElementById('email');
const message = document.getElementById('msg');

inputField.addEventListener('focus', function() {
    message.style.display = 'block';
});

inputField.addEventListener('blur', function() {
    message.style.display = 'none';
});


// inputField.addEventListener('focus', () => {
//     message.style.display = 'block';
// });

// inputField.addEventListener('blur', () => {
//     message.style.display = 'none';
// });
