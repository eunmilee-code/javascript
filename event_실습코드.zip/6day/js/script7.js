const message = document.getElementById('message');
const sizeInfo = document.getElementById('sizeInfo');


// 페이지 로드 이벤트
window.addEventListener('load', function() {
    message.innerHTML = 'Hello, World!';
    updateSizeInfo();
});
// 브라우저 창 크기 변경 이벤트  (반응형 디자인..)
window.addEventListener('resize', function() {
    updateSizeInfo();
});

function updateSizeInfo() {
    sizeInfo.innerHTML = `현재 브라우저 창의 크기: ${window.innerWidth} x ${window.innerHeight}`;
}

// // 페이지 로드 이벤트
// window.addEventListener('load', () => {
//     message.innerHTML = 'Hello, World!';
//     updateSizeInfo();
// });
// // 브라우저 창 크기 변경 이벤트
// window.addEventListener('resize', () => {
//     updateSizeInfo();
// });
// function updateSizeInfo() {
//     sizeInfo.innerHTML = `현재 브라우저 창의 크기: ${window.innerWidth} x ${window.innerHeight}`;
// }
