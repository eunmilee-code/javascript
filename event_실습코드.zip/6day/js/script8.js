window.addEventListener('error', function(event) {
    alert('An error occurred: ' + event.message + '\n' + 'In file: ' + event.filename + '\n' + 'At line: ' + event.lineno);
});
